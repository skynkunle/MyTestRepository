package com.library.system;


import java.io.InputStream;
import java.util.Properties;

/**
 * 
 */

/**
 * @author ram
 *
 */
public class ConfigManager {
	
	public static String CONFIG_FILE_NAME ="config.properties";

	private static Properties props = new Properties();
	private static InputStream in = null;
		
	/**
	 * Method returns the Property
	 * @param  _propertyName <code> String </code>
	 * @return <code> String </code>
	 */
	public static String getProperty(String _propertyName) {
		String _propertyValue = null;
		if (props != null) {
			_propertyValue = props.getProperty(_propertyName);
		}
		return _propertyValue;
	}

	/**
	 * Method loads the Config File
	 */
	public static void load() {
		try {
			//Loading properties from property file
			in = ConfigManager.class.getResourceAsStream(CONFIG_FILE_NAME);
			props.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static {
		load();
	}
	
}
