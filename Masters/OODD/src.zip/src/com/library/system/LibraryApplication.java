package com.library.system;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/* This applet demonstrates using the CardLayout manager.
 Pressing one of three buttons will cause a different "card" to be
 displayed.
 */

public class LibraryApplication extends JApplet implements ActionListener {
	public static final String USERS_SEARCH = new String("Users Are: ");

	public static final String SUCCESS_LABEL = new String(
			"Successfully rigistered,Please login Now");

	public static final String SUCCESS_UNSUBSCRIBE = new String(
			" YOU HAVE SUCCESSFULLY UNSUBSCRIBED  ");

	public static final String FAILURE_LABEL = new String("Sorry,Try again !");

	public static final String LOGGEDOUT_LABEL = new String(
			"YOU HAVE SUCCESSFULLY LOGGED OUT      ");

	private static final String UPDATESUCCESS_LABEL = new String(
			"Successfully Profile Updated");
	// JPanel loginP;
	JButton signIn;
	JTextField userFieldtxt;
	JPasswordField passFieldtxt;
	JLabel userLabel, passLabel, errormsgLabel;
	JPanel registPanel;
	JButton registerButton;
	JTextField userRegFieldtxt;
	JPasswordField passRegFieldtxt;
	JLabel userRegLabel, passRegLabel, userRegTypeLabel;
	JList userRegTypeList;
	LibraryUtility libUtil;
	private String loggedUser = "";
	private int loggedUserId;

	private JPanel adBkaddBookPanel;
	private JLabel adBkaddBookLabel, adBkbookNameLbl, adBkqtyBooksLbl,
			adBkbookCodeLbl, adBkbookCodeTypeLbl;
	private JTextField adBkbookNameTxt, adBkqtyBooksTxt, adBkbookCodeText;
	private JButton adBkaddBookButton;
	JButton myupdateProfileButton, myProfileUpdateButton;

	JPanel frame = new JPanel();
	JPanel headerPanel, mainPanel; // the container that will hold the various

	// "cards"

	JPanel buttonP; // panel to hold left side buttons

	JPanel loginP, searchP, signUpP, profileP, reportP, deleteP,
			ededitProfilePanel; // each of

	// these
	// panels

	// will constitute the "cards"

	JButton loginButton, searchButton, signUpButton, unSubscribeButton,
			logoutButton, addUserButton, deleteUserButton, addBookButton,
			bookReservationButton, bookReturnButton, borrowBookButton,
			bookRenewButton, updateProfileButton, updateProfilesButton;// left
	// side
	// panel

	JPanel brbookReturnPanel;
	JLabel brbookReturnLabel, bruserNameLbl, brbookNameLbl;
	JList bruserNameList, brbookNameList;
	JButton brreturnButton;

	// default buttons
	JButton signInButton, signUpPanelButton, submitDetails,
			customizeSearchPanelButton, deleteSearch; // the panel buttons

	CardLayout ourLayout;

	// BoxLayout buttonLayout;
	JTextField userNameTxt, firstNameTxt, lastNameTxt, locationTxt,
			contactNumberTxt, mailTxt, countryTxt, zipcodeTxt, genderTxt,
			statusTxt, userNameSignInTxt, searchTxt, deleteSearchTxt;// the

	// JPasswordField passwrdTxt,passwordSignInTxt;

	JTextField passwrdTxt, passwordSignInTxt;

	JLabel reportLabel, errorLabel, succLabel, userNameLabel, passWordLabel,
			firstNamelabel, lastNameLabel, locationLabel, contatcNumberLabel,
			mailLabel, countryLabel, zipcodeLabel, genderLabel, statusLabel,
			profileErrorLabel, profileSuccLabel, signInUserNameLabel,
			signInPasswordLabel, errorSignInLabel, searchLabel, headerLabel,
			loggedMesgReport, addUserLabel, deletePanelLabel;

	List userList = new List(20, false);

	List userList1 = new List(20, false);
	Font myFont1 = new Font("TimesRoman", Font.BOLD, 20);// Font of header
	// panel can be set
	// here
	JPanel bookReservePanel;
	JLabel bookReserveLabel, userNameLbl, bookNameLbl, errorMsgLbl;
	JList userNameList, bookNameList;
	JButton reserveButton, updateProfButton;

	private JPanel boborrowBookPanel;
	private JLabel boborrowBookLabel, bobookNameLbl, bouserIdLbl,
			boTypeOfLoanLbl;
	private JTextField bobookNameTxt, bouserIdTxt, boTypeOfLoanTxt;
	private JList bouserNameList, bobookNameList, boTypeOfLoanList;
	private JButton boborrowButton;

	JLabel ededitProfileLabel, eduserNameLbl, edfirstNameLbl, edlastNameLbl,
			edaddressLbl;
	JTextField eduserNameTxt, edfirstNameTxt, edlastNameTxt, edaddressTxt;
	JList eduserNamesList;
	JButton edupdateProfileButton;

	JLabel myeditProfileLabel, myuserNameLbl, myfirstNameLbl, mylastNameLbl,
			myaddressLbl;
	JTextField myuserNameTxt, myfirstNameTxt, mylastNameTxt, myaddressTxt;
	JList myuserNamesList;
	JButton mysupdateProfileButton;

	protected String userType = "u";
	protected String globalUser = "u";

	// private LibraryUtility libUtil;

	public void init() {
		libUtil = new LibraryUtility();
		// create cardPanel which is the panel that will contain the three
		// "cards"
		mainPanel = new JPanel();
		// create the CardLayout object
		buttonP = new JPanel();

		ourLayout = new CardLayout();
		// updateProfButton=new JButton("update Profile");

		// for button p
		buttonP.setBorder(BorderFactory.createLineBorder(Color.pink));
		BoxLayout layout = new BoxLayout(buttonP, BoxLayout.Y_AXIS);
		buttonP.setLayout(layout);

		// set card Panel's layout to be our Card Layout
		mainPanel.setLayout(ourLayout);

		// below are sign In panel items
		myProfileUpdateButton = new JButton("update me");
		myProfileUpdateButton.addActionListener(this);
		JPanel loginFrame = new JPanel();
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Container pane=frame.getContentPane();
		// pane.setVisible(true);
		errormsgLabel = new JLabel("");
		errormsgLabel.setBackground(Color.RED);
		userLabel = new JLabel("userName");
		passLabel = new JLabel("password");
		userFieldtxt = new JTextField(12);
		passFieldtxt = new JPasswordField(12);
		loginButton = new JButton("signIn");

		// Use the content pane's default BorderLayout. No need for
		// setLayout(new BorderLayout());
		// Display the window.
		// loginFrame.setResizable(true);
		// loginFrame.pack();

		bookReservationButton = new JButton("Book Reserve");
		bookReturnButton = new JButton("book return");
		borrowBookButton = new JButton("borrow book");
		bookRenewButton = new JButton("book renewal");
		updateProfileButton = new JButton("update profile");
		bookReservationButton.addActionListener(this);
		bookReturnButton.addActionListener(this);
		borrowBookButton.addActionListener(this);
		bookRenewButton.addActionListener(this);
		updateProfileButton.addActionListener(this);

		loginFrame.setVisible(true);

		signInUserNameLabel = new JLabel("Username:");
		signInPasswordLabel = new JLabel("Password:");
		errorSignInLabel = new JLabel("");
		userNameSignInTxt = new JTextField(12);
		passwordSignInTxt = new JPasswordField(12);
		addUserLabel = new JLabel("Please Enter ");

		// below are signup panel items
		errorLabel = new JLabel();
		succLabel = new JLabel();
		userNameTxt = new JTextField(12);
		passwrdTxt = new JPasswordField(12);
		signInButton = new JButton("Sign In");

		brbookReturnPanel = new JPanel();
		brbookReturnLabel = new JLabel("BOOK RETURN");
		bruserNameLbl = new JLabel("UserName");
		bruserNameList = new JList(libUtil.getUserIds());
		brbookNameLbl = new JLabel("bookName");
		brbookNameList = new JList(libUtil.getBookNames());
		brreturnButton = new JButton("return Book");
		brreturnButton.addActionListener(this);
		brbookReturnPanel.add(brbookReturnLabel);
		brbookReturnPanel.add(bruserNameLbl);
		brbookReturnPanel.add(bruserNameList);
		brbookReturnPanel.add(brbookNameLbl);
		brbookReturnPanel.add(brbookNameList);
		brbookReturnPanel.add(brreturnButton);

		boborrowBookPanel = new JPanel(new FlowLayout());
		boborrowBookLabel = new JLabel("Enter Book Details For Loan");
		bobookNameLbl = new JLabel("Book Name");
		bouserIdLbl = new JLabel("userName");
		boTypeOfLoanLbl = new JLabel("Loan Type");
		// bookCodeTypeLbl = new JLabel("(book code contains 10 characters)");
		bobookNameTxt = new JTextField(12);
		bouserIdTxt = new JTextField(10);
		boTypeOfLoanTxt = new JTextField(12);
		boborrowButton = new JButton("Borrow Book");
		bouserNameList = new JList(libUtil.getUserIds());
		bobookNameList = new JList(libUtil.getBookNames());
		boTypeOfLoanList = new JList(new String[] { "3 weekLoan", "1 weekLoan",
				"1 day Collection" });

		boborrowBookPanel.add(boborrowBookLabel);
		boborrowBookPanel.add(bobookNameLbl);
		boborrowBookPanel.add(bobookNameList);
		boborrowBookPanel.add(bouserIdLbl);
		boborrowBookPanel.add(bouserNameList);
		boborrowBookPanel.add(boTypeOfLoanLbl);
		boborrowBookPanel.add(boTypeOfLoanList);
		// borrowBookPanel.add(bookNameTxt);
		boborrowBookPanel.add(boborrowButton);
		boborrowButton.addActionListener(this);

		ededitProfilePanel = new JPanel(new FlowLayout());
		ededitProfileLabel = new JLabel("Update Profile");
		eduserNamesList = new JList(new LibraryUtility().getUserIds());
		eduserNameLbl = new JLabel("UserName");
		eduserNameTxt = new JTextField(12);
		edfirstNameLbl = new JLabel("firstName");
		edfirstNameTxt = new JTextField(12);
		edlastNameLbl = new JLabel("lastName");
		edlastNameTxt = new JTextField(12);
		edaddressLbl = new JLabel("address");
		edaddressTxt = new JTextField(12);

		edupdateProfileButton = new JButton("update Profile");
		edupdateProfileButton.addActionListener(this);

		ededitProfilePanel.add(ededitProfileLabel);
		ededitProfilePanel.add(eduserNameLbl);
		ededitProfilePanel.add(eduserNamesList);
		ededitProfilePanel.add(edfirstNameLbl);
		ededitProfilePanel.add(edfirstNameTxt);
		ededitProfilePanel.add(edlastNameLbl);
		ededitProfilePanel.add(edlastNameTxt);
		ededitProfilePanel.add(edaddressLbl);
		ededitProfilePanel.add(edaddressTxt);
		ededitProfilePanel.add(edupdateProfileButton);
		

		myeditProfileLabel = new JLabel("Update My Profile");
		myuserNamesList = new JList(new LibraryUtility().getUserIds());
		myuserNameLbl = new JLabel("UserName");
		myuserNameTxt = new JTextField(12);
		myfirstNameLbl = new JLabel("firstName");
		myfirstNameTxt = new JTextField(12);
		mylastNameLbl = new JLabel("lastName");
		mylastNameTxt = new JTextField(12);
		myaddressLbl = new JLabel("address");
		myaddressTxt = new JTextField(12);

		myupdateProfileButton = new JButton("update my Profile");
		myupdateProfileButton.addActionListener(this);

		adBkaddBookLabel = new JLabel("Enter Book Details Here");
		adBkbookNameLbl = new JLabel("Book Name");
		adBkqtyBooksLbl = new JLabel("No of Books");
		adBkbookCodeLbl = new JLabel("Book Code");
		adBkbookCodeTypeLbl = new JLabel("(book code contains 10 characters)");
		adBkbookNameTxt = new JTextField(12);
		adBkqtyBooksTxt = new JTextField(10);
		adBkbookCodeText = new JTextField(12);

		addBookButton = new JButton("addBook");
		addBookButton.addActionListener(this);
		adBkaddBookPanel = new JPanel();
		adBkaddBookPanel.setLayout(new FlowLayout());
		adBkaddBookButton = new JButton("add Book");

		adBkaddBookPanel.add(adBkaddBookLabel);
		adBkaddBookPanel.add(adBkbookCodeLbl);
		adBkaddBookPanel.add(adBkbookCodeText);
		adBkaddBookPanel.add(adBkbookCodeTypeLbl);
		adBkaddBookPanel.add(adBkqtyBooksLbl);
		adBkaddBookPanel.add(adBkqtyBooksTxt);
		adBkaddBookPanel.add(adBkbookNameLbl);
		adBkaddBookPanel.add(adBkbookNameTxt);
		adBkaddBookPanel.add(adBkaddBookButton);
		adBkaddBookButton.addActionListener(this);

		bookReservePanel = new JPanel();
		bookReserveLabel = new JLabel("BOOK RESERVATION");
		errorMsgLbl = new JLabel("");
		errorMsgLbl.setBackground(Color.RED);
		userNameLbl = new JLabel("UserName");
		userNameList = new JList(libUtil.getUserIds());
		bookNameLbl = new JLabel("bookName");
		bookNameList = new JList(libUtil.getBookNames());
		reserveButton = new JButton("reserve");
		reserveButton.addActionListener(this);
		bookReservePanel.add(bookReserveLabel);
		bookReservePanel.add(errorMsgLbl);
		bookReservePanel.add(userNameLbl);
		bookReservePanel.add(userNameList);
		bookReservePanel.add(bookNameLbl);
		bookReservePanel.add(bookNameList);
		bookReservePanel.add(reserveButton);

		userNameLabel = new JLabel("Username");
		passWordLabel = new JLabel("Password");
		signUpPanelButton = new JButton("Register");

		// report panel items
		// for report panel items
		reportLabel = new JLabel("");

		loggedMesgReport = new JLabel(
				"Congratulations ! You have Successfully logged into the System ");
		loggedMesgReport.setHorizontalAlignment(SwingConstants.RIGHT);

		loggedMesgReport.setFont(myFont1);
		loggedMesgReport.setForeground(Color.blue);
		reportP = new JPanel();
		reportP.add(reportLabel);
		// reportP.setBackground(Color.PINK);

		// header panel
		headerLabel = new JLabel("Library management System ");
		Font myFont = new Font("TimesRoman", Font.BOLD, 30);// Font of header
		// panel can be set
		// heer

		headerLabel.setFont(myFont);
		headerLabel.setForeground(Color.pink);

		loginP = new JPanel();
		loginP.add(errorSignInLabel);
		loginP.add(signInUserNameLabel);
		loginP.add(userNameSignInTxt);
		loginP.add(signInPasswordLabel);
		loginP.add(passwordSignInTxt);
		loginP.add(signInButton);
		loginP.setBackground(Color.pink);

		userRegTypeLabel = new JLabel("userType");
		String[] userTypes = { "underGrauate", "postgraduate", "staff" };
		userRegTypeList = new JList(userTypes);
		signUpP = new JPanel();

		signUpP.add(addUserLabel);
		signUpP.add(errorLabel);
		signUpP.add(succLabel);
		userNameLabel.setOpaque(false);
		userNameLabel.setAlignmentX(0.0f);
		userNameLabel.setSize(15, 5);
		signUpP.add(userNameLabel);
		signUpP.add(userNameTxt);
		passWordLabel.setOpaque(false);
		passWordLabel.setAlignmentX(0.0f);
		passWordLabel.setSize(15, 5);
		signUpP.add(passWordLabel);
		signUpP.add(passwrdTxt);
		signUpP.add(userRegTypeLabel);
		signUpP.add(userRegTypeList);
		signUpP.add(signUpPanelButton);
		signUpP.setBackground(Color.cyan);

		profileP = new JPanel();

		profileP.setBorder(BorderFactory.createLineBorder(Color.cyan));

		BoxLayout profileLayout = new BoxLayout(profileP, BoxLayout.Y_AXIS);
		profileP.setLayout(profileLayout);
		profileP.add(myeditProfileLabel);
		profileP.add(eduserNameLbl);
		profileP.add(eduserNameTxt);
		profileP.add(edfirstNameLbl);
		profileP.add(edfirstNameTxt);
		profileP.add(edlastNameLbl);
		profileP.add(edlastNameTxt);
		profileP.add(edaddressLbl);
		profileP.add(edaddressTxt);
		updateProfButton = new JButton("update my profile");
		profileP.add(updateProfButton);

		// create buttonP panel buttons and add ActionListener
		loginButton = new JButton("login");
		loginButton.setOpaque(false);
		loginButton.setAlignmentX(0.0f);
		loginButton.addActionListener(this);

		// loginButton.setBounds(25,20,20,30);

		searchButton = new JButton("search");
		searchButton.setOpaque(false);
		searchButton.setAlignmentX(0.0f);
		searchButton.addActionListener(this);
		// searchButton.setBounds(50,40,40,50);

		signUpButton = new JButton("signUp");
		// signUpButton.setBounds(75,70,80,80);
		signUpButton.setOpaque(false);
		signUpButton.setAlignmentX(0.0f);

		signUpButton.addActionListener(this);

		logoutButton = new JButton("Logout");
		logoutButton.addActionListener(this);
		logoutButton.setOpaque(false);
		logoutButton.setAlignmentX(0.0f);
		// signUpButton.setBounds(100,100,100,100);

		// sub panel buttons
		signUpPanelButton.addActionListener(this);
		signInButton.addActionListener(this);

		updateProfilesButton = new JButton("Update Profiles");
		updateProfilesButton.addActionListener(this);

		// list
		userList.addActionListener(this);

		// create Panel for the buttons and add the buttons to it

		// Panel's default Layout manager is FlowLayout

		buttonP.add(loginButton);
		// buttonP.add(searchButton);
		buttonP.add(signUpButton);

		buttonP.setBackground(Color.cyan);
		// buttonP.setLayout(new BoxLayout(buttonP, countComponents()));
		buttonP.setPreferredSize(new Dimension(115, 400));
		// buttonP.setSize(10, 200);

		headerPanel = new JPanel();
		headerPanel.setPreferredSize(new Dimension(400, 70));
		headerPanel.add(headerLabel);
		// setLayout for applet to be BorderLayout
		this.setLayout(new BorderLayout());
		// button Panel goes left, card panels go Center
		this.add(headerPanel, BorderLayout.NORTH);
		this.add(buttonP, BorderLayout.WEST);
		this.add(mainPanel, BorderLayout.CENTER);
		this.setPreferredSize(new Dimension(400, 400));
		headerPanel.setBackground(Color.cyan);
		headerPanel.setBorder(BorderFactory.createLineBorder(Color.pink));
		// add the three card panels to the card panel container
		// method takes 1.) an Object (the card) 2.) an identifying String
		// first one added is the visible one when applet appears

		mainPanel.add(loginP, "login"); // blue
		mainPanel.add(signUpP, "signUp"); // green
		mainPanel.add(adBkaddBookPanel, "addBook");
		mainPanel.add(brbookReturnPanel, "bookReturn");
		mainPanel.add(boborrowBookPanel, "bookBorrow");
		mainPanel.add(bookReservePanel, "bookReserve");
		mainPanel.add(ededitProfilePanel, "editProfile");
		mainPanel.add(profileP, "profile");
		mainPanel.add(reportP, "report");

		// mainPanel.setPreferredSize(new Dimension(400, 400));

		// addMouseListener(new MyMouseListener());
	}

	// ------------------------------------
	// respond to Button clicks by showing the so named Panel
	// note use of the CardLayout method show(Container, "identifying string")

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == brreturnButton) {
			boolean returnedDone = libUtil.returnBook(""
					+ bruserNameList.getAnchorSelectionIndex(), brbookNameList
					.getAnchorSelectionIndex()
					+ "");
			reportP.removeAll();
			reportP.add(reportLabel);
			if (returnedDone)
				reportLabel.setText("Book Returned Done");
			else
				reportLabel
						.setText("Unable to return Book Now.... please try again");

			ourLayout.show(mainPanel, "report");
		}
		if (e.getSource() == boborrowButton) {
			boolean borrowingDone = libUtil.borrowBook(bouserNameList
					.getAnchorSelectionIndex()
					+ "", bobookNameList.getAnchorSelectionIndex() + "",
					boTypeOfLoanList.getAnchorSelectionIndex() + "");
			if (borrowingDone) {
				reportP.removeAll();
				reportP.add(reportLabel);

				reportLabel.setText("Book issue is done"
						+ "\n"
						+ "your submission date is:"
						+ libUtil.getTargetForSelectedLoan(boTypeOfLoanList
								.getAnchorSelectionIndex()));
				ourLayout.show(mainPanel, "report");
			}
		}
		if (e.getSource() == adBkaddBookButton) {
			boolean addingBook = libUtil.addBook(adBkbookCodeText.getText(),
					Integer.parseInt(adBkqtyBooksTxt.getText()),
					adBkbookNameTxt.getText());
			System.out.println("book added");
			reportP.removeAll();
			reportP.add(reportLabel);
			reportLabel.setText("Book is added");
			ourLayout.show(mainPanel, "report");

		}

		if (e.getSource() == edupdateProfileButton) {
			libUtil.updateProfile(""
					+ eduserNamesList.getAnchorSelectionIndex(), edfirstNameTxt
					.getText(), edlastNameTxt.getText(),
					edaddressTxt.getText(), "0");
			reportP.removeAll();

			reportLabel.setText(UPDATESUCCESS_LABEL);
			reportLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			Font myFont2 = new Font("TimesRoman", Font.BOLD, 20);// Font of

			reportLabel.setFont(myFont2);
			reportLabel.setForeground(Color.blue);
			reportP.add(reportLabel);
			edfirstNameTxt.setText("");
			edlastNameTxt.setText("");
			edaddressTxt.setText("");

			ourLayout.show(mainPanel, "report");
		}

		if (e.getSource() == logoutButton) {
			userNameTxt.setText("");
			userNameSignInTxt.setText("");
			passwordSignInTxt.setText("");
			passwrdTxt.setText("");
			userType = "u";
			userList.removeAll();
			userList1.removeAll();

			reportP.removeAll();
			reportP.add(reportLabel);
			// to remove buttons after log in ---start
			buttonP.removeAll();
			buttonP.add(loginButton);
			buttonP.add(signUpButton);

			// to remove buttons after log in ---End

			System.out.println("Successsfully logged out");
			// buttonP.removeAll();
			reportLabel.setText(LOGGEDOUT_LABEL);
			reportLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			Font myFont2 = new Font("TimesRoman", Font.BOLD, 20);// Font of
			// header
			// panel can
			// be set
			// here
			reportLabel.setFont(myFont2);
			reportLabel.setForeground(Color.blue);

			ourLayout.show(mainPanel, "report");
			repaint();

		}
		if (e.getSource() == addBookButton) {
			System.out.println("add book++++++++++++=");
			ourLayout.show(mainPanel, "addBook");
		}
		if (e.getSource() == loginButton) {
			System.out.println("login++++++++++++=");
			errorSignInLabel.setText("");
			ourLayout.show(mainPanel, "login");
		}
		if (e.getSource() == bookReservationButton) {
			System.out.println("book reservation++++++++++++=");
			errorSignInLabel.setText("");
			ourLayout.show(mainPanel, "bookReserve");
		}
		if (e.getSource() == bookReturnButton) {
			System.out.println("book return++++++++++++=");
			errorSignInLabel.setText("");
			ourLayout.show(mainPanel, "bookReturn");
		}
		if (e.getSource() == borrowBookButton) {
			System.out.println("borrow++++++++++++=");
			errorSignInLabel.setText("");
			ourLayout.show(mainPanel, "bookBorrow");
		}
		if (e.getSource() == updateProfilesButton) {
			System.out.println("update profile ++++++++++++=");
			errorSignInLabel.setText("");
			ourLayout.show(mainPanel, "editProfile");
		}

		if (e.getSource() == searchButton) {
			System.out.println("search1");
			// to display results for the first search --start
			// searchP.add(userSearchLabel);
			searchP.add(userList1);
			// to display results for the first srearch --End
			ourLayout.show(mainPanel, "search");
			// searchP.remove(userSearchLabel);
			userList1.removeAll();
			searchP.remove(userList);

		}

		if (e.getSource() == myProfileUpdateButton) {
			System.out.println("------------");
			ourLayout.show(mainPanel, "updateMe");
		}

		if (e.getSource() == signInButton) {
			System.out.println("signInButton");
			ourLayout.show(mainPanel, "login");

			// sign IN implementation

			if (userNameSignInTxt.getText().equalsIgnoreCase("")) {
				System.out
						.println("It shoud be there+++++++++++++++++++++++++++++++");
				JOptionPane.showMessageDialog(null, "Please enter Username ");

				// validate = true;

			} else if (passwordSignInTxt.getText().equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(null, "Please enter password ");

				// validate = true;

			} else if (loggedIn()) {
				int userType = libUtil.validateUser(
						userNameSignInTxt.getText(), passwordSignInTxt
								.getText());
				loggedUser = userNameSignInTxt.getText();
				loggedUserId = libUtil.getUserIdFromUserName(userNameSignInTxt
						.getText());
				System.out.println(loggedUserId);

				switch (userType) {
				case 0:
					buttonP.remove(loginButton);
					buttonP.remove(signUpButton);
					buttonP.add(addBookButton);
					buttonP.add(bookReservationButton);
					buttonP.add(bookReturnButton);
					buttonP.add(borrowBookButton);
					buttonP.add(bookRenewButton);
					buttonP.add(updateProfilesButton);
					buttonP.add(logoutButton);

					break;

				case 1:
					buttonP.remove(loginButton);
					buttonP.remove(signUpButton);
					buttonP.add(borrowBookButton);
					buttonP.add(bookRenewButton);
					buttonP.add(updateProfileButton);
					buttonP.add(logoutButton);
					break;
				case 2:
					buttonP.remove(loginButton);
					buttonP.remove(signUpButton);
					buttonP.add(borrowBookButton);
					buttonP.add(bookRenewButton);
					buttonP.add(updateProfileButton);
					buttonP.add(logoutButton);
				case 3:
					buttonP.remove(loginButton);
					buttonP.remove(signUpButton);
					buttonP.add(borrowBookButton);
					buttonP.add(bookRenewButton);
					buttonP.add(updateProfileButton);
					buttonP.add(logoutButton);
				}
				reportP.removeAll();
				reportP.add(loggedMesgReport);
				ourLayout.show(mainPanel, "report");

			} else {
				System.out.println("UserName not exist ,Try again or SignUP");
				JOptionPane
						.showMessageDialog(null,
								"UserName or Password does not match ,Try again or SignUP");

				ourLayout.show(mainPanel, "login");
			}

		}

		if (e.getSource() == signUpButton) {
			System.out.println("signUp");
			signUpP.remove(errorLabel);
			signUpP.remove(succLabel);
			ourLayout.show(mainPanel, "signUp");

		}

		if (e.getSource() == signUpPanelButton) {

			String userName = userNameTxt.getText();
			// String passWord =passwrdTxt.getPassword().toString();
			String passWord = passwrdTxt.getText();
			if (validateUsername(userName)) {
				libUtil.registerUser(userName, passWord, ""
						+ userRegTypeList.getAnchorSelectionIndex());
				System.out.println("if success");

				reportP.removeAll();
				reportP.add(reportLabel);

				reportLabel.setText(SUCCESS_LABEL);

				ourLayout.show(mainPanel, "report");

			}
		}
		if (e.getSource() == reserveButton) {
			boolean isAvailable = libUtil.getAvailabilityOfBook(bookNameList
					.getAnchorSelectionIndex());
			if (isAvailable)
				JOptionPane.showMessageDialog(null, "The Book is in the Shelf");
			// errorMsgLbl.setText("The Book is in the Shelf");
			else {
				if (true) {
					boolean isEligibleForThatBook = new LibraryUtility()
							.validateUserForThatBook(userNameList
									.getAnchorSelectionIndex(), bookNameList
									.getAnchorSelectionIndex());
					if (!isEligibleForThatBook)
						JOptionPane.showMessageDialog(null,
								"you have already that book");

					// errorMsgLbl.setText("you have already that book");
				} else {
					boolean isReserved = libUtil.reserveBook(""
							+ userNameList.getAnchorSelectionIndex(), ""
							+ bookNameList.getAnchorSelectionIndex());
					if (isReserved) {
						reportP.removeAll();
						reportP.add(reportLabel);

						reportLabel.setText("Book Reserved");

						ourLayout.show(mainPanel, "report");
					}

				}

			}

		}

	}

	private boolean loggedIn() {
		boolean result = false;

		int userType = libUtil.validateUser(userNameSignInTxt.getText(),
				passwordSignInTxt.getText());

		System.out.println(userType);

		if (userType == -99) {
			// errormsgLabel.setText("Invalid userId or password");
			result = false;
		} else {
			System.out.println("correct user" + userType);
			result = true;

		}

		return result;

	}

	boolean validateUsername(String userName) {
		boolean validate = true;
		if (userName.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter Username ");

			validate = false;
		} else if (passwrdTxt.getText().equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(null, "Please enter password ");

			validate = false;
		} else if (userRegTypeList.getAnchorSelectionIndex() < 0) {
			JOptionPane.showMessageDialog(null, "Please enter Usertype ");
			validate = false;
			// if username and password is not empty
		} else {
			// TODO : checking wavailability
		}
		return validate;
	}

}
