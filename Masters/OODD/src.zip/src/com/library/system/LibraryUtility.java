package com.library.system;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class LibraryUtility {

	/**
	 * @param args
	 */
	String absolPath = "";

	public LibraryUtility() {
		ConfigManager configMgr = new ConfigManager();
		absolPath = configMgr.getProperty("path");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LibraryUtility().getUserIds();

	}

	public void issueBook() {

	}

	public boolean borrowBook(String userName, String bookName, String loanType) {
		boolean borrowingDone = false;
		try {			
			File file = new File(absolPath + "Borrower_Details.txt");
			System.out.println("file created");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			int i = 0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}

			outputStream.println(i + ":" + userName + ":" + bookName + ":"
					+ loanType + ":" + new Date() + ":"
					+ getTargetForSelectedLoan(Integer.parseInt(loanType)));
			outputStream.close();
			borrowingDone=true;
		} catch (Exception ee) {
			ee.printStackTrace();
			borrowingDone=false;
		}

		return borrowingDone;

	}
	public int getUserIdFromUserName(String userName)
	{
		boolean found=false;
		int idForUserName=-99;
		Object[] userIds=getUserIds();
		for(int i=0;i<userIds.length;i++)
		{
			
			if(userIds[i].toString().equalsIgnoreCase(userName))
				idForUserName=i;
				break;
		}
		return idForUserName;

	}

	public boolean returnBook(String userName, String bookName) {
		// if (ae.getActionCommand().equalsIgnoreCase("return Book")) {
		boolean returnedDone = false;
		try {
			File file = new File(absolPath + "Borrower_returns.txt");
			System.out.println("file created");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			int i = 0;
			double fine = 0.0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}
			outputStream.println(i + ":" + userName + ":" + bookName + ":"
					+ new Date() + ":" + fine + "$");
			outputStream.close();
			returnedDone = true;
		} catch (Exception ee) {
			ee.printStackTrace();
			returnedDone = false;
		}
		return returnedDone;

	}
	public boolean addBook(String bookCode, int noOfBooks, String bookName) {
		//int isExistedthatBook=checkIsExisted(bookCode);
		int bookCount = 0;
		boolean addingBook=false;
		try {
			File file = new File(
					absolPath+"book_copy.txt");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			int i = 0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}
			outputStream.println(i + ":" + bookCode + ":" + noOfBooks + ":"
					+ bookName + ":" + new Date());
			bookCount = i;
			outputStream.close();
			br.close();
			addingBook=true;
		} catch (Exception ee) {
			ee.printStackTrace();
			addingBook=false;
		}
		return addingBook;
	}

	public int checkIsExisted(String bookCode) {
		int noOfBooksAlreadyAvailable=0;
		try {
			File file = new File(
					absolPath+"book_copy.txt");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;			
			boolean validateAvailability;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
			      String[] bookDetail=inLine.split(":");
			      if(bookCode.equals(bookDetail[1]))
			      {
			    	  noOfBooksAlreadyAvailable=Integer.parseInt(bookDetail[2]);
			    	  validateAvailability=true;
			    	  break;
			      }
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return noOfBooksAlreadyAvailable;
	}

	public boolean reserveBook(String userName, String bookName) {
		boolean reservedDone = false;
		try {
			File file = new File(absolPath + "Book_Reservations.txt");
			System.out.println("file created");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			// System.out.println(userFieldtxt.getText()+":"+passFieldtxt.getText()+":"+userTypeList.getAnchorSelectionIndex()+new
			// Date());
			int i = 0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}
			outputStream.println(i + ":" + userName + ":" + bookName + ":"
					+ new Date());
			outputStream.close();
			reservedDone = true;

		} catch (Exception ae) {
			ae.printStackTrace();
			reservedDone = false;
		}
		return reservedDone;
	}

	public void registerUser(String userName, String pass, String userType) {
		try {
			File file = new File(absolPath + "user_Registrations.txt");
			System.out.println("file created");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			int i = 0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}
			outputStream.println(i + ":" + userName + ":" + pass + ":"
					+ userType + ":" + new Date());
			outputStream.close();
		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}

	public int validateUser(String userId, String password) {
		int userType = -99;
		try {
			File file = new File(absolPath + "user_Registrations.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;
			if (userId.equals("admin") && password.equals("admin"))
				userType = 0;
			else {
				while ((inLine = br.readLine()) != null) {
					System.out.println(inLine);
					boolean validate;
					String[] s = inLine.split(":");
					if (s[1].equals(userId) && s[2].equals(password)) {
						userType = Integer.parseInt(s[3]);
						break;
					} else
						userType = -99;
				}
			}

		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return userType;

	}

	public boolean updateProfile(String userId, String firstName,
			String lastName, String address, String updatedUserId) {
		try {
			File file = new File(absolPath + "user_Profile.txt");
			System.out.println("file created");
			FileReader inputFileReader = new FileReader(file);
			FileWriter outputFileReader = new FileWriter(file, true);
			BufferedReader br = new BufferedReader(inputFileReader);
			PrintWriter outputStream = new PrintWriter(outputFileReader);
			String inLine = null;
			int i = 0;
			String lastStr = null;
			while ((inLine = br.readLine()) != null) {
				i++;
			}
			outputStream.println(i + ":" + userId + ":" + firstName + ":"
					+ lastName + ":" + address + ":" + updatedUserId + ":"
					+ new Date());
			outputStream.close();
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return true;
	}

	public boolean validateUserForMoreBooks(int Id) {
		boolean validate = true;
		int count = getCountOfMainLoansForUserId(Id);
		String userType = getUserTypeFromId(Id);
		switch (Integer.parseInt(userType)) {
		case 0:
			validate = count <= 16 ? true : false;
			break;
		case 1:
			validate = count <= 20 ? true : false;
			break;
		default:
			validate = count <= 35 ? true : false;
			break;

		}

		return validate;
	}

	public boolean validateUserForThatBook(int userId, int bookId) {
		boolean isAlreadyWithHim = false, isEligibleForThatBook = false;
		try {
			File borrowerfile = new File(absolPath + "Borrower_Details.txt");
			File bReturnsFile = new File(absolPath + "Borrower_Returns.txt");
			FileReader inputFileReader = new FileReader(borrowerfile);
			BufferedReader br = new BufferedReader(inputFileReader);
			FileReader inputborrowerReader = new FileReader(bReturnsFile);
			BufferedReader brBorrower = new BufferedReader(inputborrowerReader);
			String inLine = null;
			String inBrLine = null;
			Date returningDate = null;
			Date returnedDate = null;

			// int i = 0;

			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				returningDate = new Date(Date.parse(s[4]));
				long diffInDates = 0;
				long returnDate = Date.parse(s[4]);
				long currentDate = new Date().getTime();
				diffInDates = returnDate - currentDate;
				if (((Integer.parseInt(s[1]) == userId) && (Integer
						.parseInt(s[2]) == bookId))
						&& (diffInDates > 863999999)) {
					isAlreadyWithHim = true;
					break;
				}

			}
			while ((inBrLine = brBorrower.readLine()) != null) {
				String[] st = inBrLine.split(":");
				returnedDate = new Date(Date.parse(st[3]));
				if (isAlreadyWithHim) {
					if (((Integer.parseInt(st[1]) == userId) && (Integer
							.parseInt(st[2]) == bookId))
							&& (returningDate.compareTo(returnedDate) > 0)) {
						isEligibleForThatBook = true;
						break;
					}
				} else
					isEligibleForThatBook = true;

			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return isEligibleForThatBook;
	}

	public Date getPossibleNearByReturndateForTheBook(int bookId) {

		return new Date();
	}

	public Date getTargetForSelectedLoan(int LoanType) {
		Calendar current = Calendar.getInstance();
		Calendar target = Calendar.getInstance();
		switch (LoanType) {
		case 0:
			target.add(Calendar.DATE, 21);
			break;
		case 1:
			target.add(Calendar.DATE, 7);
			break;
		default:
			target.add(Calendar.DATE, 1);
			break;

		}
		return target.getTime();
	}

	public int getCountOfMainLoansForUserId(int Id) {
		String userName = getNameFromId(Id);
		String userType = getUserTypeFromId(Id);
		int countForMainColl = 0;
		try {
			File file = new File(absolPath + "Borrower_Details.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			// int i = 0;
			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				if ((s[1].equals(userName)) && (Integer.parseInt(s[3]) == 0))
					countForMainColl++;
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}

		return countForMainColl;
	}

	public Object[] getUserIds() {
		ArrayList<String> al = new ArrayList<String>();
		try {
			File file = new File(absolPath + "user_Registrations.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			// int i = 0;
			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				System.out.println(s[3]);
				al.add(s[1]);

				// i++;
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return al.toArray();
	}

	public String getNameFromId(int userId) {
		String userName = "0";
		try {
			File file = new File(absolPath + "user_Registrations.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				if (s[0].equals(userId)) {
					userName = s[1];
					break;
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return userName;

	}

	public String getUserTypeFromId(int userId) {
		String userType = "0";
		try {
			File file = new File(absolPath + "user_Registrations.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				if (s[0].equals(userId)) {
					userType = s[3];
					break;
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return userType;

	}

	public Object[] getBookNames() {
		ArrayList<String> bNames = new ArrayList<String>();
		try {
			File file = new File(absolPath + "book_copy.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				bNames.add(s[3]);

			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return bNames.toArray();
	}

	public boolean getAvailabilityOfBook(int bookId) {
		try {
			File bookFile = new File(absolPath + "book_copy.txt");
			File borrowerFile = new File(absolPath + "Borrower_Details.txt");

			FileReader inputbookFileReader = new FileReader(bookFile);
			BufferedReader brBook = new BufferedReader(inputbookFileReader);
			FileReader inputBorrowerFileReader = new FileReader(bookFile);
			BufferedReader brBorrower = new BufferedReader(
					inputBorrowerFileReader);

			String inLine = null;

			while ((inLine = brBook.readLine()) != null) {
				String[] s = inLine.split(":");

			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return true;

	}

	public String getBookCodefromBookName(String bookName) {
		String bookCode = "";
		try {
			File file = new File(absolPath + "book_copy.txt");
			FileReader inputFileReader = new FileReader(file);
			BufferedReader br = new BufferedReader(inputFileReader);
			String inLine = null;

			while ((inLine = br.readLine()) != null) {
				String[] s = inLine.split(":");
				if (s[3].equals(bookName)) {
					bookCode = s[1];
					break;
				}

			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return bookCode;
	}

}
